/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef ��Ŀ1_PRIVATE_H
#define ��Ŀ1_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"2.1.2.0"
#define VER_MAJOR	2
#define VER_MINOR	1
#define VER_RELEASE	2
#define VER_BUILD	0
#define COMPANY_NAME	""
#define FILE_VERSION	"2.1.2.0"
#define FILE_DESCRIPTION	"����С����"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"Alice-Cartelet"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	"2.1.2.0"

#endif /*��Ŀ1_PRIVATE_H*/
